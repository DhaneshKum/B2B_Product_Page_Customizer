<?php
// class-ppc-product-variants-display.php
if (!defined('ABSPATH')) exit;

class PPC_Product_Variants_Display {
    private $table_rendered = false;

    public function __construct() {
        add_action('woocommerce_after_single_product_summary', [$this, 'render_variants_table'], 5);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_ajax_add_variants_to_cart', [$this, 'add_variants_to_cart']);
        add_action('wp_ajax_nopriv_add_variants_to_cart', [$this, 'add_variants_to_cart']);
    }

    public function enqueue_assets() {
        if (!is_product()) return;

        global $post;
        $product = wc_get_product($post);
        if (!$product || !$product->is_type('variable')) return;

        wp_enqueue_script('wc-add-to-cart');
        wp_enqueue_script('wc-add-to-cart-variation');

        wp_enqueue_style(
            'ppc-variants-table',
            PPC_URL . 'assets/public/css/variants-table.css',
            [],
            PPC_VERSION
        );

        wp_enqueue_script(
            'ppc-variants',
            PPC_URL . 'assets/public/js/variants-table.js',
            ['jquery', 'wc-add-to-cart', 'wc-add-to-cart-variation'],
            PPC_VERSION,
            true
        );

        wp_localize_script('ppc-variants', 'ppcData', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('add_variants_to_cart'),
            'product_id' => $product->get_id(),
            'i18n' => [
                'min_quantity_error' => __('You must add at least %d item(s).', 'product-page-customizer'),
                'max_quantity_error' => __('You cannot add more than %d items. The maximum quantity limit has been reached.', 'product-page-customizer')
            ]
        ]);
    }

    public function add_variants_to_cart() {
        check_ajax_referer('add_variants_to_cart', 'nonce');

        $items = isset($_POST['items']) ? (array)$_POST['items'] : [];
        $success_count = 0;

        foreach ($items as $item) {
            if (empty($item['variation_id']) || empty($item['quantity'])) {
                continue;
            }

            $variation_id = absint($item['variation_id']);
            $product_id = absint($item['product_id']);
            $quantity = absint($item['quantity']);
            $variation = wc_get_product($variation_id);

            if (!$variation || !$variation->is_purchasable() || !$variation->is_in_stock()) {
                wc_add_notice(
                    sprintf(
                        __('Variation #%s is not available.', 'product-page-customizer'),
                        $variation_id
                    ),
                    'error'
                );
                continue;
            }

            $min_max_enabled = get_option('ppc_enable_min_max_order', 'no') === 'yes';
            if ($min_max_enabled) {
                $min_max_handler = new PPC_Product_Min_Max_Quantity();
                $min_qty = $min_max_handler->get_min_quantity($variation_id);
                $max_qty = $min_max_handler->get_max_quantity($variation_id);
            } else {
                $min_qty = 1;
                $variation_obj = wc_get_product($variation_id);
                $stock_qty = $variation_obj ? $variation_obj->get_stock_quantity() : 9999;
                $max_qty = $stock_qty !== null ? $stock_qty : 9999;
            }

            $cart = WC()->cart;
            $total_qty = 0;
            if ($cart) {
                $cart_items = $cart->get_cart();
                foreach ($cart_items as $key => $cart_item) {
                    $pid = isset($cart_item['variation_id']) && $cart_item['variation_id'] ? $cart_item['variation_id'] : $cart_item['product_id'];
                    if ($pid == $variation_id) {
                        $total_qty += $cart_item['quantity'];
                    }
                }
            }
            $total_qty += $quantity;

            if ($total_qty > $max_qty) {
                wc_add_notice(
                    sprintf(
                        __('You cannot add more than %d items. The maximum quantity limit has been reached.', 'product-page-customizer'),
                        $max_qty
                    ),
                    'error'
                );
                continue;
            }

            if ($total_qty < $min_qty) {
                wc_add_notice(
                    sprintf(
                        __('You must add at least %d item(s).', 'product-page-customizer'),
                        $min_qty
                    ),
                    'error'
                );
                continue;
            }

            $added = WC()->cart->add_to_cart(
                $product_id,
                $quantity,
                $variation_id,
                wc_clean($item['attributes'])
            );

            if ($added) {
                $success_count++;
            } else {
                wc_add_notice(
                    sprintf(
                        __('Failed to add variation #%s to cart.', 'product-page-customizer'),
                        $variation_id
                    ),
                    'error'
                );
            }
        }

        if ($success_count > 0) {
            wc_add_notice(
                sprintf(
                    _n(
                        '%d item added to cart.',
                        '%d items added to cart.',
                        $success_count,
                        'product-page-customizer'
                    ),
                    $success_count
                ),
                'success'
            );
        } else {
            wc_add_notice(
                __('No items were added to cart.', 'product-page-customizer'),
                'error'
            );
        }

        ob_start();
        wc_print_notices();
        $notices_html = ob_get_clean();

        wp_send_json_success([
            'cart_count' => WC()->cart->get_cart_contents_count(),
            'cart_total' => WC()->cart->get_cart_total(),
            'notices' => $notices_html
        ]);
    }

    public function render_variants_table() {
        global $product;

        if ($this->table_rendered) {
            return;
        }

        if (!$product || !$product->is_type('variable')) {
            return;
        }

        $enable_global = get_option('ppc_variants_set_global') === 'yes' && get_option('ppc_enable_variants_table') === 'yes';
        $enable_individual = get_option('ppc_variants_set_individual') === 'yes';

        if ($enable_individual) {
            if (get_post_meta($product->get_id(), '_ppc_enable_variants_table', true) !== 'yes') {
                return;
            }
        } elseif (!$enable_global) {
            return;
        }

        $all_variations = [];
        $variation_ids = $product->get_children();
        
        foreach ($variation_ids as $variation_id) {
            $variation = wc_get_product($variation_id);
            if (!$variation || !$variation->is_purchasable()) continue;

            $variation_attributes = $variation->get_variation_attributes();
            $variation_data = [
                'variation_id' => $variation_id,
                'attributes' => $variation_attributes,
                'price_html' => $variation->get_price_html(),
                'is_in_stock' => $variation->is_in_stock(),
                'display_values' => []
            ];

            foreach ($variation_attributes as $attr_name => $attr_value) {
                $taxonomy = str_replace('attribute_', '', $attr_name);
                if (taxonomy_exists($taxonomy)) {
                    $term = get_term_by('slug', $attr_value, $taxonomy);
                    $variation_data['display_values'][$attr_name] = $term ? $term->name : $attr_value;
                } else {
                    $variation_data['display_values'][$attr_name] = $attr_value;
                }
            }

            $all_variations[] = $variation_data;
        }

        if (empty($all_variations)) {
            return;
        }

        $all_attributes = [];
        foreach ($all_variations as $variation) {
            foreach ($variation['attributes'] as $attr_name => $attr_value) {
                if (!isset($all_attributes[$attr_name])) {
                    $taxonomy = str_replace('attribute_', '', $attr_name);
                    $all_attributes[$attr_name] = [
                        'name' => wc_attribute_label($taxonomy),
                        'values' => []
                    ];
                }
                if (!empty($attr_value)) {
                    $all_attributes[$attr_name]['values'][$attr_value] = $variation['display_values'][$attr_name];
                }
            }
        }

        $global_message = get_option('ppc_variants_global_msg', '');
        
        ?>
        <div class="ppc-variants-wrapper">
            <?php if ($enable_global && !empty($global_message)): ?>
                <div class="ppc-variants-global-message"><?php echo esc_html($global_message); ?></div>
            <?php endif; ?>
            <form class="ppc-variants-form" method="post">
                <?php wp_nonce_field('add_variants_to_cart', 'variants_nonce'); ?>
                <table class="ppc-variants-table">
                    <thead>
                        <tr>
                            <th class="select-col">
                                <input type="checkbox" class="select-all" title="<?php esc_attr_e('Select all', 'product-page-customizer'); ?>">
                            </th>
                            <?php foreach ($all_attributes as $attr_key => $attr_data): ?>
                                <th><?php echo esc_html($attr_data['name']); ?></th>
                            <?php endforeach; ?>
                            <th><?php esc_html_e('Price', 'product-page-customizer'); ?></th>
                            <th><?php esc_html_e('Quantity', 'product-page-customizer'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($all_variations as $variation): ?>
                            <tr class="variant-row<?php echo !$variation['is_in_stock'] ? ' out-of-stock' : ''; ?>">
                                <td>
                                    <input type="checkbox" 
                                           class="variant-select" 
                                           name="variant_selected[]"
                                           value="<?php echo esc_attr($variation['variation_id']); ?>"
                                           <?php disabled(!$variation['is_in_stock']); ?>
                                           data-price="<?php echo esc_attr(wc_get_product($variation['variation_id'])->get_price()); ?>"
                                           data-variation-id="<?php echo esc_attr($variation['variation_id']); ?>"
                                           data-product-id="<?php echo esc_attr($product->get_id()); ?>"
                                           data-attributes="<?php echo esc_attr(json_encode($variation['attributes'])); ?>">
                                </td>
                                <?php foreach ($all_attributes as $attr_key => $attr_data): 
                                    $attr_value = isset($variation['display_values'][$attr_key]) ? $variation['display_values'][$attr_key] : '';
                                ?>
                                    <td><?php echo esc_html($attr_value); ?></td>
                                <?php endforeach; ?>
                                <td class="price"><?php echo $variation['price_html']; ?></td>
                                <td class="quantity">
                                    <div class="quantity-wrapper">
                                        <button type="button" 
                                                class="qty-btn minus" 
                                                tabindex="0"
                                                <?php disabled(!$variation['is_in_stock']); ?>
                                                aria-label="<?php esc_attr_e('Decrease quantity', 'product-page-customizer'); ?>" 
                                                disabled>−</button>
                                        <input type="number" 
                                               class="qty-input" 
                                               name="quantity[<?php echo esc_attr($variation['variation_id']); ?>]"
                                               value="0" 
                                               step="1"
                                               pattern="[0-9]*"
                                               inputmode="numeric"
                                               <?php disabled(!$variation['is_in_stock']); ?>
                                               aria-label="<?php esc_attr_e('Product quantity', 'product-page-customizer'); ?>"
                                               disabled>
                                        <button type="button" 
                                                class="qty-btn plus" 
                                                tabindex="0"
                                                <?php disabled(!$variation['is_in_stock']); ?>
                                                aria-label="<?php esc_attr_e('Increase quantity', 'product-page-customizer'); ?>" 
                                                disabled>+</button>
                                    </div>
                                    <?php if (!$variation['is_in_stock']): ?>
                                        <p class="stock out-of-stock"><?php esc_html_e('Out of stock', 'product-page-customizer'); ?></p>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div class="ppc-variants-actions">
                    <button type="submit" class="button alt add-to-cart-button" disabled>
                        <?php esc_html_e('Add Selected to Cart', 'product-page-customizer'); ?>
                    </button>
                </div>
            </form>
        </div>
        <?php
        
        $this->table_rendered = true;
    }
}

new PPC_Product_Variants_Display();
?>