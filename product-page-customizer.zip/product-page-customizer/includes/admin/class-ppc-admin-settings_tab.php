<?php
if (!defined('ABSPATH')) exit;

class PPC_Admin_Settings
{
    public function __construct()
    {
        add_filter('woocommerce_settings_tabs_array', [$this, 'add_settings_tab'], 50);
        add_action('woocommerce_settings_tabs_ppc_settings', [$this, 'display_settings']);
        add_action('woocommerce_update_options_ppc_settings', [$this, 'save_settings']);
        add_action('woocommerce_admin_field_toggle_switch', [$this, 'render_toggle_switch_field']);
    }

    public function add_settings_tab($settings_tabs)
    {
        $settings_tabs['ppc_settings'] = __('Product Page Customizer', 'product-page-customizer');
        return $settings_tabs;
    }

    /**
     * Render custom toggle switch field
     */
    public function render_toggle_switch_field($value)
    {
        $option_value = WC_Admin_Settings::get_option($value['id'], $value['default']);
        $field_name = esc_attr($value['id']);
        $field_id = esc_attr($value['id']);
        $description = WC_Admin_Settings::get_field_description($value);
        ?>
        <tr valign="top">
            <th scope="row" class="titledesc">
                <label for="<?php echo $field_id; ?>"><?php echo esc_html($value['title']); ?></label>
                <!-- <?php echo $description['tooltip_html']; ?> -->
            </th>
            <td class="forminp forminp-<?php echo sanitize_title($value['type']); ?>">
                <label class="ppc-toggle-switch">
                    <input 
                        type="checkbox" 
                        id="<?php echo $field_id; ?>" 
                        name="<?php echo $field_name; ?>" 
                        value="yes" 
                        <?php checked($option_value, 'yes'); ?>
                    />
                    <span class="ppc-toggle-slider"></span>
                </label>
                <span class="description"><?php echo wp_kses_post($value['desc']); ?></span>
                <!-- <?php echo $description['description']; ?> -->
            </td>
        </tr>
        <?php
    }

    public function get_settings()
    {
        $settings = [

            // Section 1: Attachments
            [
                'name' => __('Product PDF Settings', 'product-page-customizer'),
                'type' => 'title',
                'desc' => "Upload and control product's guide PDF.",
                'id'   => 'ppc_pdf_settings_title'
            ],
            [
                'title'    => __('Product Pdf Uploader', 'product-page-customizer'),
                'desc'     => __('Want to add attachments on the individual product page.', 'product-page-customizer'),
                'id'       => 'ppc_enable_pdf',
                'type'     => 'toggle_switch',
                'default'  => 'no',
                'desc_tip' => true,
            ],
            ['type' => 'sectionend', 'id' => 'ppc_pdf_settings_title'],

            // Section 2: Min/Max
            [
                'name' => __('Min/Max Order Quantity', 'product-page-customizer'),
                'type' => 'title',
                'desc' => 'Set minimum and maximum order quantities for products.',
                'id'   => 'ppc_min_max_order_settings_title'
            ],
            [
                'title'    => __('Globally Set Min/Max Order Quantity', 'product-page-customizer'),
                'desc'     => __('want to set globally minimum and maximum order quantities for products.', 'product-page-customizer'),
                'id'       => 'ppc_enable_min_max_order',
                'type'     => 'toggle_switch',
                'default'  => 'no',
            ],
            [
                'name'     => __('Minimum Quantity', 'product-page-customizer'),
                'desc_tip' => __('Minimum quantity must be greater than 0.', 'product-page-customizer'),
                'id'       => 'ppc_min_quantity',
                'type'     => 'number',
                'class'    => 'ppc_min_max_fields',
                'css'      => 'width:50px;',
                'default'  => 1,
                'custom_attributes' => ['min' => 1]
            ],
            [
                'name'     => __('Maximum Quantity', 'product-page-customizer'),
                'desc_tip' => __('Maximum quantity must be greater than 0.', 'product-page-customizer'),
                'id'       => 'ppc_max_quantity',
                'type'     => 'number',
                'class'    => 'ppc_min_max_fields',
                'css'      => 'width:50px;',
                'default'  => 10,
                'custom_attributes' => ['min' => 1]
            ],
            ['type' => 'sectionend', 'id' => 'ppc_min_max_order_settings_title'],

            // Section 3: You Save
            [
                'name' => __('"You Save" Message', 'product-page-customizer'),
                'type' => 'title',
                'desc' => __('Display a custom "You Save" message showing the discount amount on product pages.', 'product-page-customizer'),
                'id'   => 'ppc_you_save_message_settings_title'
            ],
            [
                'title'    => __('Enable "You Save" Message', 'product-page-customizer'),
                'desc'     => __('Enable this feature to display a custom "You Save" message on product and shop pages.', 'product-page-customizer'),
                'id'       => 'ppc_enable_you_save',
                'type'     => 'toggle_switch',
                'default'  => 'no',
            ],
            [
                'title'    => __('Set Per Product', 'product-page-customizer'),
                'desc'     => __('Enable this to define custom messages per product from the product editor.', 'product-page-customizer'),
                'id'       => 'ppc_you_save_set_individual',
                'type'     => 'toggle_switch',
                'default'  => 'no',
                'class'    => 'ppc_you_save_mode_checkbox'
            ],
            [
                'title'    => __('Set Globally', 'product-page-customizer'),
                'desc'     => __('Enable this to use the global message and display location defined below.', 'product-page-customizer'),
                'id'       => 'ppc_you_save_set_global',
                'type'     => 'toggle_switch',
                'default'  => 'yes',
                'class'    => 'ppc_you_save_mode_checkbox'
            ],
            [
                'name' => __('Global Custom Message', 'product-page-customizer'),
                'id'   => 'ppc_you_save_custom_msg',
                'type' => 'text',
                'css'  => 'min-width: 300px;',
                'default' => __('You Save', 'product-page-customizer'),
                'desc_tip' => true,
                'desc' => __('This is the text prefix for the savings amount. Example: "You Save ₨2"', 'product-page-customizer'),
                'class' => 'ppc_you_save_global_only'
            ],
            [
                'name' => __('Display Position', 'product-page-customizer'),
                'id'   => 'ppc_you_save_display_position',
                'type' => 'select',
                'options' => [
                    'after_cart' => __('After Add to Cart Button (default)', 'product-page-customizer'),
                    'before_cart' => __('Before Add to Cart Button', 'product-page-customizer'),
                ],
                'default' => 'after_cart',
                'desc_tip' => __('Choose where to display the "You Save" message on the product page.', 'product-page-customizer'),
                'class' => 'ppc_you_save_global_only'
            ],
            ['type' => 'sectionend', 'id' => 'ppc_you_save_message_settings_title'],

            // Section 4: Variants Display Settings
            [
                'name' => __('Variants Display Settings', 'product-page-customizer'),
                'type' => 'title',
                'desc' => __('Control how product variants are displayed on product pages.', 'product-page-customizer'),
                'id'   => 'ppc_variants_display_settings_title'
            ],
            [
                'title'    => __('Enable Variants Table', 'product-page-customizer'),
                'desc'     => __('Enable variants table display on product pages.', 'product-page-customizer'),
                'id'       => 'ppc_enable_variants_table',
                'type'     => 'toggle_switch',
                'default'  => 'no',
            ],
            [
                'title'    => __('Set Per Product', 'product-page-customizer'),
                'desc'     => __('Enable this to control variants table display per product.', 'product-page-customizer'),
                'id'       => 'ppc_variants_set_individual',
                'type'     => 'toggle_switch',
                'default'  => 'no',
                'class'    => 'ppc_variants_mode_checkbox'
            ],
            [
                'title'    => __('Set Globally', 'product-page-customizer'),
                'desc'     => __('Enable this to use global settings for all products.', 'product-page-customizer'),
                'id'       => 'ppc_variants_set_global',
                'type'     => 'toggle_switch',
                'default'  => 'yes',
                'class'    => 'ppc_variants_mode_checkbox'
            ],
            ['type' => 'sectionend', 'id' => 'ppc_variants_display_settings_title'],

            // Section 5: Product Sample Request
            [
                'title' => __('Request for Samples', 'woocommerce'),
                'desc'  => __('Allow request for product sample.'),
                'type'  => 'title',
                'id'    => 'sample_settings_title'
            ],
            [
                'title'    => __('Product Sample Requests', 'woocommerce'),
                'desc'     => __('Allow users to request a sample product.', 'woocommerce'),
                'id'       => 'enable_sample_request',
                'default'  => 'no',
                'type'     => 'toggle_switch',
            ],
            [
                'title'    => __('Set Custom Label', 'woocommerce'),
                'desc_tip' => __('Set button label text for requesting a sample.', 'woocommerce'),
                'id'       => 'sample_button_label',
                'default'  => 'Request For Sample',
                'type'     => 'text'
            ],
            [
                'type' => 'sectionend',
                'id'   => 'sample_settings_title'
            ]
        ];

        return apply_filters('ppc_admin_settings', $settings);
    }

    public function display_settings()
    {
        woocommerce_admin_fields($this->get_settings());
    }

    public function save_settings()
    {
        // Save custom toggle_switch fields
        foreach ($this->get_settings() as $field) {
            if (isset($field['id']) && isset($field['type']) && $field['type'] === 'toggle_switch') {
                $option = isset($_POST[$field['id']]) ? 'yes' : 'no';
                update_option($field['id'], $option);
            }
        }
        // Save other fields as usual
        woocommerce_update_options($this->get_settings());
    }

   
}

new PPC_Admin_Settings();
