<?php
if (!defined('ABSPATH')) exit;

class PPC_Product_Min_Max_Quantity
{
    public function __construct()
    {
        // Only validate if global feature is enabled
        if ('yes' === get_option('ppc_enable_min_max_order', 'no')) {
            // Frontend validation hooks
            add_filter('woocommerce_add_to_cart_validation', [$this, 'validate_quantity'], 10, 3);
add_filter('woocommerce_update_cart_validation', array($this, 'validate_cart_update_moq'), 99, 4);

            // Admin product tab hooks
            add_filter('woocommerce_product_data_tabs', [$this, 'add_min_max_tab']);
            add_action('woocommerce_product_data_panels', [$this, 'add_min_max_fields']);
            add_action('woocommerce_process_product_meta', [$this, 'save_min_max_fields']);
        }
    }

/**
 * Validate min/max quantity on cart update (cart page) using woocommerce_update_cart_validation filter.
 * This function receives: $passed, $cart_item_key, $values, $quantity
 */
public function validate_cart_update_moq($passed, $cart_item_key, $values, $quantity) {
    // Get product/variation ID
    $product_id = isset($values['variation_id']) && $values['variation_id'] ? $values['variation_id'] : $values['product_id'];
    $min = $this->get_min_quantity($product_id);
    $max = $this->get_max_quantity($product_id);

    // Calculate total quantity for this product/variation in the cart after update
    $cart = WC()->cart;
    $total_qty = 0;
    if ($cart) {
        $cart_items = $cart->get_cart();
        foreach ($cart_items as $key => $item) {
            $pid = isset($item['variation_id']) && $item['variation_id'] ? $item['variation_id'] : $item['product_id'];
            if ($pid == $product_id) {
                // If this is the item being updated, use the new $quantity, else use existing
                $item_qty = ($key === $cart_item_key) ? $quantity : $item['quantity'];
                $total_qty += $item_qty;
            }
        }
    }

    if ($total_qty > $max) {
        wc_add_notice(
            sprintf( __( 'You cannot add more than %d items. The maximum quantity limit has been reached.', 'product-page-customizer' ), $max ),
            'error'
        );
        return false;
    }

    if ($total_qty < $min) {
        wc_add_notice(
            sprintf( __( 'You must add at least %d item(s).', 'product-page-customizer' ), $min ),
            'error'
        );
        return false;
    }

    return $passed;
}

    /**
     * Add Min/Max Quantity tab to Product Data tabs
     */
    public function add_min_max_tab($tabs) {
        $tabs['ppc_min_max'] = [
            'label'    => __('Min/Max Quantity', 'product-page-customizer'),
            'target'   => 'ppc_min_max_product_data',
            'class'    => ['show_if_simple', 'show_if_variable'],
            'priority' => 85,
        ];
        return $tabs;
    }

    /**
     * Add fields to Min/Max Quantity tab
     */
    public function add_min_max_fields() {
        global $post;
        $product = wc_get_product($post->ID);
        if ($product && $product->is_type('grouped')) {
            echo '<div id="ppc_min_max_product_data" class="panel woocommerce_options_panel"><div class="options_group">';
            echo '<p>' . __('Min/Max settings are not applicable to grouped products. Please set min/max for each child product individually.', 'product-page-customizer') . '</p>';
            echo '</div></div>';
            return;
        }

        $global_min = get_option('ppc_min_quantity', 1);
        $global_max = get_option('ppc_max_quantity', 10);

        echo '<div id="ppc_min_max_product_data" class="panel woocommerce_options_panel">';
        echo '<div class="options_group">';

        echo '<p class="form-field">';
        echo '<label>' . __('Global Settings', 'product-page-customizer') . '</label>';
        echo '<span class="description">' . sprintf(__('Global Min: %d, Global Max: %d', 'product-page-customizer'), $global_min, $global_max) . '</span>';
        echo '</p>';

        // Checkbox with proper ID
        woocommerce_wp_checkbox([
            'id'          => '_ppc_use_individual_moq',
            'label'       => __('Use Individual Min/Max Quantity?', 'product-page-customizer'),
            'description' => __('Enable to use this product\'s own Min/Max Quantity. If unchecked, global values will be used.', 'product-page-customizer'),
        ]);

        // Start Wrapper for Min/Max fields
        echo '<div id="ppc_min_max_wrapper">';

        // Minimum Quantity field
        woocommerce_wp_text_input([
            'id'          => '_ppc_min_qty',
            'label'       => __('Minimum Quantity', 'product-page-customizer'),
            'desc_tip'    => true,
            'description' => __('Set custom Minimum Quantity for this product. Leave empty to use global setting.', 'product-page-customizer'),
            'type'        => 'number',
            'custom_attributes' => [
                'min'  => '1',
                'step' => '1'
            ]
        ]);

        // Maximum Quantity field
        woocommerce_wp_text_input([
            'id'          => '_ppc_max_qty',
            'label'       => __('Maximum Quantity', 'product-page-customizer'),
            'desc_tip'    => true,
            'description' => __('Set custom Maximum Quantity for this product. Leave empty to use global setting.', 'product-page-customizer'),
            'type'        => 'number',
            'custom_attributes' => [
                'min'  => '1',
                'step' => '1'
            ]
        ]);

        echo '</div>'; // End Wrapper
        echo '</div>'; // End options_group
        echo '</div>'; // End panel

        // JavaScript for toggling
        ?>
        <script type="text/javascript">
        jQuery(document).ready(function($) {
            function toggleMinMaxFields() {
                if ($('#_ppc_use_individual_moq').is(':checked')) {
                    $('#ppc_min_max_wrapper').show();
                } else {
                    $('#ppc_min_max_wrapper').hide();
                }
            }

            toggleMinMaxFields(); // Initial run
            $('#_ppc_use_individual_moq').on('change', toggleMinMaxFields); // On checkbox change
        });
        
        </script>
        <?php
    }

    /**
     * Save Min/Max Quantity fields
     */
    public function save_min_max_fields($post_id) {
        $product = wc_get_product($post_id);
        if (!$product || $product->is_type('grouped')) {
            return;
        }

        // Save minimum quantity
        if (isset($_POST['_ppc_min_qty'])) {
            $min_qty = absint($_POST['_ppc_min_qty']);
            if ($min_qty < 1) $min_qty = 1;
            update_post_meta($post_id, '_ppc_min_qty', $min_qty);
        }

        // Save maximum quantity
        if (isset($_POST['_ppc_max_qty'])) {
            $max_qty = absint($_POST['_ppc_max_qty']);
            if ($max_qty < 1) $max_qty = 1;
            update_post_meta($post_id, '_ppc_max_qty', $max_qty);
        }

        // Save use individual MOQ checkbox
        $use_individual_moq = isset($_POST['_ppc_use_individual_moq']) ? 'yes' : 'no';
        update_post_meta($post_id, '_ppc_use_individual_moq', $use_individual_moq);

        // If this is a variable product, apply settings to all variations
        if ($product->is_type('variable')) {
            $variations = $product->get_children();
            foreach ($variations as $variation_id) {
                if (isset($_POST['_ppc_min_qty'])) {
                    update_post_meta($variation_id, '_ppc_min_qty', $min_qty);
                }
                if (isset($_POST['_ppc_max_qty'])) {
                    update_post_meta($variation_id, '_ppc_max_qty', $max_qty);
                }
            }
        }
    }

    /**
     * Get min quantity for a product
     */
    public function get_min_quantity($product_id) {
        $product = wc_get_product($product_id);
        if (!$product || $product->is_type('grouped')) {
            return null;
        }

        // Check if individual MOQ is enabled
        $use_individual = get_post_meta($product_id, '_ppc_use_individual_moq', true);
        if ($product->is_type('variation') && $use_individual !== 'yes') {
            $parent_id = $product->get_parent_id();
            $use_individual = get_post_meta($parent_id, '_ppc_use_individual_moq', true);
        }

        if ($use_individual === 'yes') {
            $individual_min = get_post_meta($product_id, '_ppc_min_qty', true);
            if ($product->is_type('variation') && empty($individual_min)) {
                $parent_id = $product->get_parent_id();
                $individual_min = get_post_meta($parent_id, '_ppc_min_qty', true);
            }
            if (!empty($individual_min)) {
                return $individual_min;
            }
        }
        return get_option('ppc_min_quantity', 1);
    }

    /**
     * Get max quantity for a product
     */
    public function get_max_quantity($product_id) {
        $product = wc_get_product($product_id);
        if (!$product || $product->is_type('grouped')) {
            return null;
        }

        // Check if individual MOQ is enabled
        $use_individual = get_post_meta($product_id, '_ppc_use_individual_moq', true);
        if ($product->is_type('variation') && $use_individual !== 'yes') {
            $parent_id = $product->get_parent_id();
            $use_individual = get_post_meta($parent_id, '_ppc_use_individual_moq', true);
        }

        if ($use_individual === 'yes') {
            $individual_max = get_post_meta($product_id, '_ppc_max_qty', true);
            if ($product->is_type('variation') && empty($individual_max)) {
                $parent_id = $product->get_parent_id();
                $individual_max = get_post_meta($parent_id, '_ppc_max_qty', true);
            }
            if (!empty($individual_max)) {
                return $individual_max;
            }
        }
        return get_option('ppc_max_quantity', 10);
    }

    /**
     * Validate quantity against min/max limits
     */
    public function validate_quantity($passed, $product_id, $quantity)
    {
        $product = wc_get_product($product_id);
        if (!$product || $product->is_type('grouped')) {
            return $passed;
        }

        // For variable products, we need to check the variation
        if ($product->is_type('variable')) {
            // Get the variation ID from the cart item data
            $variation_id = isset($_POST['variation_id']) ? absint($_POST['variation_id']) : 0;
            if ($variation_id) {
                $product_id = $variation_id;
            }
        }

        // Get min/max quantities for this product/variation
        $min = $this->get_min_quantity($product_id);
        $max = $this->get_max_quantity($product_id);


        // Get current cart quantity for this product/variation
        $cart = WC()->cart;
        $current_cart_qty = 0;
        if ($cart) {
            $cart_items = $cart->get_cart();
            foreach ($cart_items as $cart_item) {
                if ($cart_item['product_id'] == $product_id || 
                    (isset($cart_item['variation_id']) && $cart_item['variation_id'] == $product_id)) {
                    $current_cart_qty += $cart_item['quantity'];
                }
            }
        }

        // Calculate total quantity after adding new items
        $total_qty = $current_cart_qty + $quantity;
        
        

       if ( $total_qty > $max ) {
         wc_add_notice(
             sprintf( __( 'You cannot add more than %d items. The maximum quantity limit has been reached.', 'product-page-customizer' ), $max ),
             'error'
         );
         return false;
        }
    
         // Agar total quantity min se kam hai
         if ( $total_qty < $min ) {
             wc_add_notice(
                 sprintf( __( 'You must add at least %d item(s).', 'product-page-customizer' ), $min ),
                 'error'
             );
             return false;
         }
    
         // Dono me nahi aata to passed return karo
         return $passed;
         
     
    }

    
    /**
     * Add min/max quantity data to variation data
     */
    public function add_min_max_to_variation_data($variation_data, $product, $variation) {
        

        // $variation_data['min_qty'] = 1;
        $variation_data['min_qty'] = (int) $min;
        $variation_data['max_qty'] = (int) $max;
        $variation_data['input_value'] = (int) $min;

        return $variation_data;
    }

    /**
     * Enqueue frontend scripts
     */
    // public function enqueue_scripts() {
    //     if (is_product()) {
    //         wp_enqueue_script(
    //             'ppc-min-max-quantity',
    //             PPC_URL . 'assets/public/js/min-max-quantity.js',
    //             ['jquery'],
    //             PPC_VERSION,
    //             true
    //         );
    //     }
    // }
}

new PPC_Product_Min_Max_Quantity();
