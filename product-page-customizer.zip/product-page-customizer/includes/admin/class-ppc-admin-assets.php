<?php
/**
 * Load assets
 */

if (! defined('ABSPATH') ) {
	exit;
}

if (! class_exists('PPC_Admin_Assets', false) ) :

	/**
	 * PPC_Admin_Assets Class.
	 */
	class PPC_Admin_Assets {

		public function __construct() {
            add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
		}

        public function enqueue_admin_scripts($hook) {
            $enqueue = false;
            
           wp_enqueue_style(
               'ppc_plugin_admin_styles',
               PPC_URL . 'assets/admin/css/ppc-plugin-style-admin.css',
               array(),
               PPC_VERSION
           );

            // WooCommerce settings page (custom tab)
            if ($hook === 'woocommerce_page_wc-settings' && isset($_GET['tab']) && $_GET['tab'] === 'ppc_settings') {
                $enqueue = true;
            }

            // WooCommerce product edit/add page
            if ($hook === 'post.php' || $hook === 'post-new.php') {
                global $post;
                // Only for product post type
                if (isset($post) && $post->post_type === 'product') {
                    $enqueue = true;
                }
            }

            if (!$enqueue) {
                return;
            }

            // Min/max and general settings script
            wp_enqueue_script(
                'ppc-settings-toggle-js',
                plugin_dir_url(__FILE__) . '../../assets/admin/Js/ppc-general-setting.js',
                ['jquery'],
                '1.0',
                true
            );
        }
    }

endif;

new PPC_Admin_Assets();
