<?php
if (!defined('ABSPATH')) exit;

class PPC_Product_PDF_Manager
{
    public function __construct() {
        
        if ('yes' === get_option('ppc_enable_pdf', true)) {
            
            add_filter('woocommerce_product_data_tabs', [$this, 'add_attachments_tab']);
            add_action('woocommerce_product_data_panels', [$this, 'output_attachments_tab_content']);
            add_action('woocommerce_process_product_meta', [$this, 'save_attachments_tab_data']);
            add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
        }

        // Simple PDF meta box
        add_action('add_meta_boxes', [$this, 'add_pdf_meta_box']);
        add_action('save_post', [$this, 'save_pdf_upload']);
    }

    /**
     * Add "Attachments" tab to Product Data
     */
    public function add_attachments_tab($tabs)
    {
        $tabs['ppc_attachments'] = [
            'label'    => __('Attachments', 'ppc'),
            'target'   => 'ppc_attachments_tab',
            'class'    => ['show_if_simple', 'show_if_variable'],
            'priority' => 70,
        ];
        return $tabs;
    }

    /**
     * Output content for the "Attachments" tab
     * Use WooCommerce standard field functions for all fields.
     */
    public function output_attachments_tab_content()
    {
        global $post;

        $pdf_url   = get_post_meta($post->ID, '_ppc_attachment_pdf_url', true);
        $pdf_title = get_post_meta($post->ID, '_ppc_attachment_pdf_title', true);
        $link_text = get_post_meta($post->ID, '_ppc_attachment_link_text', true);
        ?>
        <div id="ppc_attachments_tab" class="panel woocommerce_options_panel">
            <div class="options_group">
                <?php
                // PDF URL field (with upload button)
                woocommerce_wp_text_input([
                    'id'          => '_ppc_attachment_pdf_url',
                    'label'       => __('PDF URL', 'ppc'),
                    'description' => __('Select or upload a PDF file.', 'ppc'),
                    'desc_tip'    => true,
                    'type'        => 'text',
                    'value'       => $pdf_url,
                    'wrapper_class' => 'ppc-pdf-url-field',
                ]);
                ?>
                <p>
                    <button type="button" class="button ppc-upload-pdf"><?php _e('Upload PDF', 'ppc'); ?></button>
                </p>
                <?php
                // PDF Title field
                woocommerce_wp_text_input([
                    'id'          => '_ppc_attachment_pdf_title',
                    'label'       => __('PDF Title', 'ppc'),
                    'description' => __('Optional title for the PDF.', 'ppc'),
                    'desc_tip'    => true,
                    'type'        => 'text',
                    'value'       => $pdf_title,
                ]);

                // Link Text field
                woocommerce_wp_text_input([
                    'id'          => '_ppc_attachment_link_text',
                    'label'       => __('Link Text', 'ppc'),
                    'description' => __('Text to display for the download link.', 'ppc'),
                    'desc_tip'    => true,
                    'type'        => 'text',
                    'value'       => $link_text,
                ]);
                ?>
            </div>
        </div>
       
        <?php
    }

    /**
     * Save the data from the "Attachments" tab
     */
    public function save_attachments_tab_data($post_id)
    {
        if (isset($_POST['_ppc_attachment_pdf_url'])) {
            update_post_meta($post_id, '_ppc_attachment_pdf_url', esc_url_raw($_POST['_ppc_attachment_pdf_url']));
        }

        if (isset($_POST['_ppc_attachment_pdf_title'])) {
            update_post_meta($post_id, '_ppc_attachment_pdf_title', sanitize_text_field($_POST['_ppc_attachment_pdf_title']));
        }

        if (isset($_POST['_ppc_attachment_link_text'])) {
            update_post_meta($post_id, '_ppc_attachment_link_text', sanitize_text_field($_POST['_ppc_attachment_link_text']));
        }
    }

    /**
     * Enqueue media uploader script
     */
    public function enqueue_admin_scripts($hook)
    {
        if ($hook === 'post.php' || $hook === 'post-new.php') {
            wp_enqueue_script(
                'ppc-admin-pdf-uploader',
                plugins_url('../../assets/admin/Js/ppc-general-setting.js', __FILE__),
                ['jquery'],
                '1.0',
                true
            );
            wp_enqueue_media();
        }
    }

    /**
     * Add meta box for basic PDF link
     */
    public function add_pdf_meta_box()
    {
        add_meta_box(
            'ppc_product_pdf',
            __('Product User Guide PDF', 'product-page-customizer'),
            [$this, 'render_pdf_meta_box'],
            'product',
            'side',
            'default'
        );
    }

    /**
     * Render PDF Meta Box
     */
    public function render_pdf_meta_box($post)
    {
        $pdf = get_post_meta($post->ID, '_ppc_product_pdf', true);
        echo '<input type="hidden" name="ppc_pdf_nonce" value="' . wp_create_nonce('ppc_pdf_upload') . '">';
        echo '<input type="url" name="ppc_product_pdf" value="' . esc_attr($pdf) . '" style="width:100%;" placeholder="PDF URL or upload...">';
    }

    /**
     * Save PDF URL from meta box
     */
    public function save_pdf_upload($post_id)
    {
        // print_r($_POST['ppc_product_pdf']);
        // die;
        if (!isset($_POST['ppc_pdf_nonce']) || !wp_verify_nonce($_POST['ppc_pdf_nonce'], 'ppc_pdf_upload')) {
            return;
        }

        if (isset($_POST['ppc_product_pdf'])) {
            update_post_meta($post_id, '_ppc_product_pdf', esc_url_raw($_POST['ppc_product_pdf']));
        }
    }
}

new PPC_Product_PDF_Manager();
