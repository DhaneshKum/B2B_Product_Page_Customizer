jQuery(function($) {
    'use strict';

    class VariantsTable {
        constructor() {
            this.$form = $('.ppc-variants-form');
            if (this.$form.length === 0) return;

            this.$selectAll = this.$form.find('.select-all');
            this.$variantCheckboxes = this.$form.find('.variant-select');
            this.$submitButton = this.$form.find('.add-to-cart-button');
            this.$noticeContainer = $('.woocommerce-notices-wrapper').length > 0 
                ? $('.woocommerce-notices-wrapper') 
                : $('<div class="woocommerce-notices-wrapper"></div>').prependTo('.woocommerce');

            this.bindEvents();
            this.updateSelectAllState();
            this.updateSubmitButton();
        }

        bindEvents() {
            this.$variantCheckboxes.on('change', (e) => {
                const $checkbox = $(e.target);
                const $row = $checkbox.closest('tr');
                const $qtyInput = $row.find('.qty-input');
                const $qtyButtons = $row.find('.qty-btn');
                const isChecked = $checkbox.is(':checked');

                if (isChecked) {
                    $qtyInput.prop('disabled', false).val(1);
                    $qtyButtons.prop('disabled', false);
                } else {
                    $qtyInput.prop('disabled', true).val(0);
                    $qtyButtons.prop('disabled', true);
                }

                this.updateSelectAllState();
                this.updateSubmitButton();
            });

            this.$selectAll.on('change', (e) => {
                const isChecked = $(e.target).is(':checked');
                
                this.$variantCheckboxes.each((i, checkbox) => {
                    const $checkbox = $(checkbox);
                    const $row = $checkbox.closest('tr');
                    const $qtyInput = $row.find('.qty-input');
                    const $qtyButtons = $row.find('.qty-btn');

                    $checkbox.prop('checked', isChecked);
                    if (isChecked) {
                        $qtyInput.prop('disabled', false).val(1);
                    } else {
                        $qtyInput.prop('disabled', true).val(0);
                    }
                    $qtyButtons.prop('disabled', !isChecked);
                });

                this.updateSubmitButton();
            });

            this.$form.on('click', '.qty-btn', (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                const $button = $(e.currentTarget);
                if ($button.prop('disabled')) return;
                
                const $wrapper = $button.closest('.quantity-wrapper');
                const $input = $wrapper.find('.qty-input');
                if ($input.prop('disabled')) return;

                const currentVal = parseInt($input.val(), 10) || 0;
                let newVal = currentVal;

                if ($button.hasClass('plus')) {
                    newVal = currentVal + 1;
                } else if ($button.hasClass('minus') && currentVal > 0) {
                    newVal = currentVal - 1;
                }

                if (newVal !== currentVal) {
                    $input.val(newVal).trigger('change');
                    this.updateSubmitButton();
                }
            });

            this.$form.on('input', '.qty-input', (e) => {
                const $input = $(e.target);
                if ($input.prop('disabled')) return;
                this.updateSubmitButton();
            });

            this.$form.on('submit', (e) => {
                e.preventDefault();
                e.stopPropagation();

                if (this.$submitButton.prop('disabled')) return;

                const itemsToAdd = [];
                this.$variantCheckboxes.each((i, checkbox) => {
                    const $checkbox = $(checkbox);
                    if ($checkbox.is(':checked')) {
                        const $row = $checkbox.closest('tr');
                        const qty = parseInt($row.find('.qty-input').val(), 10) || 0;
                        if (qty > 0) {
                            itemsToAdd.push({
                                variationId: $checkbox.data('variation-id'),
                                qty
                            });
                        }
                    }
                });

                if (itemsToAdd.length === 0) {
                    $.post(ppcData.ajax_url, {
                        action: 'add_variants_to_cart',
                        nonce: ppcData.nonce,
                        items: []
                    }, (response) => {
                        if (response.success && response.data.notices) {
                            this.$noticeContainer.html(response.data.notices).show();
                        }
                    });
                    return;
                }

                this.addToCart(itemsToAdd);
            });

            this.$form.on('keypress', '.qty-input', (e) => {
                if (e.which === 13) {
                    e.preventDefault();
                    e.stopPropagation();
                    return false;
                }
            });
        }

        updateSelectAllState() {
            const totalCheckboxes = this.$variantCheckboxes.length;
            const checkedCheckboxes = this.$variantCheckboxes.filter(':checked').length;
            
            this.$selectAll.prop({
                checked: checkedCheckboxes > 0 && checkedCheckboxes === totalCheckboxes,
                indeterminate: checkedCheckboxes > 0 && checkedCheckboxes < totalCheckboxes
            });
        }

        updateSubmitButton() {
            let hasSelectedItems = false;

            this.$variantCheckboxes.filter(':checked').each((i, checkbox) => {
                const $checkbox = $(checkbox);
                const qty = parseInt($checkbox.closest('tr').find('.qty-input').val(), 10) || 0;
                if (qty > 0) {
                    hasSelectedItems = true;
                    return false;
                }
            });

            this.$submitButton.prop('disabled', !hasSelectedItems);
        }

        addToCart(itemsToAdd) {
            const items = [];

            this.$variantCheckboxes.filter(':checked').each((i, checkbox) => {
                const $checkbox = $(checkbox);
                const $row = $checkbox.closest('tr');
                const qty = parseInt($row.find('.qty-input').val(), 10) || 0;

                if (qty > 0) {
                    items.push({
                        product_id: $checkbox.data('product-id'),
                        variation_id: $checkbox.data('variation-id'),
                        quantity: qty,
                        attributes: $checkbox.data('attributes')
                    });
                }
            });

            if (items.length === 0) {
                $.post(ppcData.ajax_url, {
                    action: 'add_variants_to_cart',
                    nonce: ppcData.nonce,
                    items: []
                }, (response) => {
                    if (response.success && response.data.notices) {
                        this.$noticeContainer.html(response.data.notices).show();
                    }
                });
                return;
            }

            this.$form.find('input, button').prop('disabled', true);
            this.$submitButton.text('Adding to cart...');

            $.ajax({
                url: ppcData.ajax_url,
                type: 'POST',
                data: {
                    action: 'add_variants_to_cart',
                    nonce: ppcData.nonce,
                    items: items
                },
                success: (response) => {
                    if (response.success && response.data.notices) {
                        this.$noticeContainer.html(response.data.notices).show();
                    }

                    if (response.success && response.data.cart_count > 0) {
                        this.$variantCheckboxes.prop('checked', false);
                        this.$form.find('.qty-input').prop('disabled', true).val(0);
                        this.$form.find('.qty-btn').prop('disabled', true);
                        this.updateSelectAllState();
                        this.updateSubmitButton();
                    }
                },
                error: () => {
                    this.$noticeContainer.html('<div class="woocommerce-error">' + ppcData.i18n.error + '</div>').show();
                },
                complete: () => {
                    this.$form.find('input:not(.qty-input[disabled]), button:not(.qty-btn[disabled])').prop('disabled', false);
                    this.$submitButton.text('Add Selected to Cart');
                    this.updateSubmitButton();
                }
            });
        }
    }

    $(document).ready(() => {
        window.ppcVariantsTable = new VariantsTable();
    });
});