jQuery(document).ready(function($) {
    // Store the current variation ID and attributes
    var currentVariationId = 0;
    var currentVariationAttributes = {};

    // Listen for variation changes
    $('form.variations_form').on('show_variation', function(event, variation) {
        currentVariationId = variation.variation_id;
        currentVariationAttributes = variation.attributes;
        console.log('Selected variation:', variation); // Debug log
    }).on('hide_variation', function() {
        currentVariationId = 0;
        currentVariationAttributes = {};
    });

    $('#sample-request-btn').on('click', function(e) {
        e.preventDefault();

        var $button = $(this);
        var product_id = $button.data('product_id');
        var nonce = $button.data('nonce');

        // Check if this is a variable product
        if ($('form.variations_form').length) {
            // If no variation selected, show error
            if (!currentVariationId) {
                alert('Please select a variation first.');
                return;
            }

            // Get all selected variation attributes
            var $form = $('form.variations_form');
            var variationData = {};
            
            // Get all select elements in the form
            $form.find('select').each(function() {
                var $select = $(this);
                var attribute = $select.attr('name').replace('attribute_', '');
                var value = $select.val();
                if (value) {
                    variationData[attribute] = value;
                }
            });

            // Get all radio buttons in the form
            $form.find('input[type="radio"]:checked').each(function() {
                var $radio = $(this);
                var attribute = $radio.attr('name').replace('attribute_', '');
                var value = $radio.val();
                if (value) {
                    variationData[attribute] = value;
                }
            });

            currentVariationAttributes = variationData;
        }

        // Disable button
        $button.prop('disabled', true);

        // Debug log
        console.log('Sending request with:', {
            product_id: product_id,
            variation_id: currentVariationId,
            variation: currentVariationAttributes
        });

        // Add sample to cart via AJAX
        $.ajax({
            type: 'POST',
            url: ppcSampleRequest.ajaxurl,
            data: {
                action: 'add_sample_to_cart',
                product_id: product_id,
                variation_id: currentVariationId,
                variation: currentVariationAttributes,
                nonce: nonce
            },
            success: function(response) {
                console.log('Response:', response); // Debug log
                if (response.success) {
                    // Redirect to cart page
                    window.location.href = response.data.cart_url;
                } else {
                    alert(response.data.message || 'Failed to add sample to cart');
                    $button.prop('disabled', false);
                }
            },
            error: function(xhr, status, error) {
                console.error('Error:', {xhr: xhr, status: status, error: error}); // Debug log
                alert('Error occurred. Please try again.');
                $button.prop('disabled', false);
            }
        });
    });
}); 