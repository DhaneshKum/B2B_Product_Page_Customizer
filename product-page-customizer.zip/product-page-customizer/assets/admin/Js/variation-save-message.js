/**
 * Handles the "You Save" message display for variable products
 */
jQuery(document).ready(function($) {
    'use strict';

    const $variationForm = $('form.variations_form');
    const $saveMessage = $('.ppc-variation-save-message, .ppc-you-save-message');
    const $quantityInput = $('input.qty');
    const $product = $('.product');
    
    // Exit if required elements are not found
    if (!$saveMessage.length) {
        return;
    }

    // Store the current variation data
    let currentVariation = null;

    // Handle simple products
    if ($product.hasClass('simple')) {
        // Get prices from data attributes
        const $priceElement = $product.find('.price');
        const regularPrice = parseFloat($priceElement.data('regular-price'));
        const salePrice = parseFloat($priceElement.data('sale-price')) || regularPrice;

        // Debug log
        console.log('Simple Product Prices:', { regularPrice, salePrice });
        
        if (regularPrice && salePrice && regularPrice > salePrice) {
            updateSimpleProductSaveMessage(regularPrice, salePrice);
        }
    }

    // Handle variable products
    if ($variationForm.length) {
        // Get variations data from the form
        const variationsData = $variationForm.data('product_variations');

        // Calculate and display initial price range savings if available
        if (variationsData && variationsData.length > 0) {
            let minRegularPrice = Infinity;
            let maxRegularPrice = -Infinity;
            let minSalePrice = Infinity;
            let maxSalePrice = -Infinity;
            let hasAnySale = false;

            // Find min and max prices
            variationsData.forEach(variation => {
                if (variation.display_regular_price) {
                    minRegularPrice = Math.min(minRegularPrice, parseFloat(variation.display_regular_price));
                    maxRegularPrice = Math.max(maxRegularPrice, parseFloat(variation.display_regular_price));
                }
                if (variation.display_price) {
                    minSalePrice = Math.min(minSalePrice, parseFloat(variation.display_price));
                    maxSalePrice = Math.max(maxSalePrice, parseFloat(variation.display_price));
                }
                if (variation.display_regular_price > variation.display_price) {
                    hasAnySale = true;
                }
            });

            // If any variation is on sale, show the initial range message
            if (hasAnySale) {
                const minSaving = minRegularPrice - minSalePrice;
                const maxSaving = maxRegularPrice - maxSalePrice;
                let message = '';

                if (ppcSaveMessage.enable_global) {
                    message = ppcSaveMessage.global_msg + ' ';
                } else if (ppcSaveMessage.enable_individual && ppcSaveMessage.custom_msg && ppcSaveMessage.enable_save_message) {
                    message = ppcSaveMessage.custom_msg + ' ';
                }

                if (message) {
                    if (minSaving === maxSaving) {
                        message += formatPrice(minSaving);
                    } else {
                        message += formatPrice(minSaving) + ' - ' + formatPrice(maxSaving);
                    }
                    $saveMessage.html(message).show();
                }
            }
        }

        /**
         * Handles showing the save message when a variation is selected
         */
        $variationForm.on('show_variation', function(event, variation) {
            if (!variation) {
                $saveMessage.hide();
                return;
            }

            currentVariation = variation;
            updateSaveMessage();
        });

        /**
         * Reset to price range savings when variation is hidden
         */
        $variationForm.on('hide_variation reset_data', function() {
            currentVariation = null;
            if (variationsData && variationsData.length > 0) {
                // Recalculate price range savings
                let minRegularPrice = Infinity;
                let maxRegularPrice = -Infinity;
                let minSalePrice = Infinity;
                let maxSalePrice = -Infinity;
                let hasAnySale = false;

                variationsData.forEach(variation => {
                    if (variation.display_regular_price) {
                        minRegularPrice = Math.min(minRegularPrice, parseFloat(variation.display_regular_price));
                        maxRegularPrice = Math.max(maxRegularPrice, parseFloat(variation.display_regular_price));
                    }
                    if (variation.display_price) {
                        minSalePrice = Math.min(minSalePrice, parseFloat(variation.display_price));
                        maxSalePrice = Math.max(maxSalePrice, parseFloat(variation.display_price));
                    }
                    if (variation.display_regular_price > variation.display_price) {
                        hasAnySale = true;
                    }
                });

                if (hasAnySale) {
                    const minSaving = minRegularPrice - minSalePrice;
                    const maxSaving = maxRegularPrice - maxSalePrice;
                    let message = '';

                    if (ppcSaveMessage.enable_global) {
                        message = ppcSaveMessage.global_msg + ' ';
                    } else if (ppcSaveMessage.enable_individual && ppcSaveMessage.custom_msg && ppcSaveMessage.enable_save_message) {
                        message = ppcSaveMessage.custom_msg + ' ';
                    }

                    if (message) {
                        if (minSaving === maxSaving) {
                            message += formatPrice(minSaving);
                        } else {
                            message += formatPrice(minSaving) + ' - ' + formatPrice(maxSaving);
                        }
                        $saveMessage.html(message).show();
                    }
                } else {
                    $saveMessage.hide();
                }
            } else {
                $saveMessage.hide();
            }
        });
    }

    /**
     * Update save message when quantity changes
     */
    $quantityInput.on('change input', function() {
        if (currentVariation) {
            updateSaveMessage();
        } else {
            // Always try to update .ppc-you-save-message if it exists and price data is present
            const $saveMsg = $('.ppc-you-save-message');
            if ($saveMsg.length) {
                console.log('[PPC] .ppc-you-save-message found');
                let regularPrice, salePrice;
                // Try to get from .product .price first
                const $priceElement = $('.product .price');
                regularPrice = parseFloat($priceElement.data('regular-price'));
                salePrice = parseFloat($priceElement.data('sale-price'));
                // If not found, try .ppc-price-data
                if (isNaN(regularPrice) || isNaN(salePrice)) {
                    const $dataSpan = $('.ppc-price-data');
                    if ($dataSpan.length) {
                        regularPrice = parseFloat($dataSpan.data('regular-price'));
                        salePrice = parseFloat($dataSpan.data('sale-price'));
                    }
                }
                if (!isNaN(regularPrice) && isNaN(salePrice)) salePrice = regularPrice;
                console.log('[PPC] Simple Product Prices:', { regularPrice, salePrice });
                if (regularPrice && salePrice && regularPrice > salePrice) {
                    updateSimpleProductSaveMessage(regularPrice, salePrice);
                }
            }
        }
    });

    /**
     * Update the save message for simple products
     */
    function updateSimpleProductSaveMessage(regularPrice, salePrice) {
        const quantity = parseInt($quantityInput.val()) || 1;
        const savedAmount = (regularPrice - salePrice) * quantity;
        const currentPosition = getCurrentPosition();
        let message = '';

        if (ppcSaveMessage.enable_global) {
            if (ppcSaveMessage.global_position === currentPosition) {
                message = ppcSaveMessage.global_msg + ' ' + formatPrice(savedAmount);
            }
        } else if (ppcSaveMessage.enable_individual && 
                   ppcSaveMessage.custom_msg && 
                   ppcSaveMessage.enable_save_message &&
                   ppcSaveMessage.individual_position === currentPosition) {
            message = ppcSaveMessage.custom_msg + ' ' + formatPrice(savedAmount);
        }

        if (message) {
            // Add original and current price information
            message += '<br><small>(Original price: ' + formatPrice(regularPrice * quantity) + 
                      ', Current price: ' + formatPrice(salePrice * quantity) + ')</small>';
            $saveMessage.html(message).show();
        } else {
            $saveMessage.hide();
        }
    }

    /**
     * Update the save message based on current variation and quantity
     */
    function updateSaveMessage() {
        if (!currentVariation || !currentVariation.display_price || !currentVariation.display_regular_price) {
            $saveMessage.hide();
            return;
        }

        if (!ppcSaveMessage.enable_global && !(ppcSaveMessage.enable_individual && ppcSaveMessage.enable_save_message)) {
            $saveMessage.hide();
            return;
        }

        const regularPrice = parseFloat(currentVariation.display_regular_price);
        const salePrice = parseFloat(currentVariation.display_price);
        const quantity = parseInt($('input.qty').val()) || 1;
        
        // Only show message if there's a saving
        if (regularPrice > salePrice) {
            const savedAmount = (regularPrice - salePrice) * quantity;
            const currentPosition = getCurrentPosition();
            let message = '';

            if (ppcSaveMessage.enable_global) {
                message = ppcSaveMessage.global_msg + ' ' + formatPrice(savedAmount);
            } else if (ppcSaveMessage.enable_individual && ppcSaveMessage.custom_msg && ppcSaveMessage.enable_save_message) {
                message = ppcSaveMessage.custom_msg + ' ' + formatPrice(savedAmount);
            }

            if (message) {
                // Add original and current price information
                message += '<br><small>(Original price: ' + formatPrice(regularPrice * quantity) + 
                          ', Current price: ' + formatPrice(salePrice * quantity) + ')</small>';
                $saveMessage.html(message).show();
            } else {
                $saveMessage.hide();
            }
        } else {
            $saveMessage.hide();
        }
    }

    /**
     * Determines if the message is before or after the add to cart button
     * @returns {string} 'before_cart' or 'after_cart'
     */
    function getCurrentPosition() {
        const $addToCartBtn = $('.single_add_to_cart_button');
        if (!$addToCartBtn.length || !$saveMessage.length) {
            return '';
        }

        const messagePosition = $saveMessage.offset().top;
        const buttonPosition = $addToCartBtn.offset().top;
        
        return messagePosition < buttonPosition ? 'before_cart' : 'after_cart';
    }

    /**
     * Formats the price according to WooCommerce settings
     * @param {number} price - The price to format
     * @returns {string} Formatted price with currency symbol
     */
    function formatPrice(price) {
        price = Number(price).toFixed(2);
        
        switch (ppcSaveMessage.currency_pos) {
            case 'left':
                return ppcSaveMessage.currency_symbol + price;
            case 'right':
                return price + ppcSaveMessage.currency_symbol;
            case 'left_space':
                return ppcSaveMessage.currency_symbol + ' ' + price;
            case 'right_space':
                return price + ' ' + ppcSaveMessage.currency_symbol;
            default:
                return price;
        }
    }
}); 