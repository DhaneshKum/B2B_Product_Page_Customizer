



jQuery(document).ready(function ($) {
    
    // --- Min/Max Order Quantity Section ---
    function toggleMinMaxFields() {
        const enabled = $('#ppc_enable_min_max_order').is(':checked');
        $('.ppc_min_max_fields').closest('tr').toggle(enabled);
    }
    $('#ppc_enable_min_max_order').on('change', toggleMinMaxFields);
    toggleMinMaxFields();


    // --- Product Sample Request Section ---
    function toggleSampleLabelField() {
        const enabled = $('#enable_sample_request').is(':checked');
        $('#sample_button_label').closest('tr').toggle(enabled);
    }
    $('#enable_sample_request').on('change', toggleSampleLabelField);
    toggleSampleLabelField();


    // --- "You Save" Message Settings Section ---
    function toggleYouSaveModeFields(show) {
        $('#ppc_you_save_set_individual, #ppc_you_save_set_global').closest('tr').toggle(show);
    }
    function toggleYouSaveGlobalFields(show) {
        $('.ppc_you_save_global_only').closest('tr').toggle(show);
    }
    function initializeYouSaveState() {
        const enabled = $('#ppc_enable_you_save').is(':checked');
        const globalChecked = $('#ppc_you_save_set_global').is(':checked');
        toggleYouSaveModeFields(enabled);
        toggleYouSaveGlobalFields(enabled && globalChecked);
    }
    $('#ppc_enable_you_save').on('change', function () {
        const enabled = $(this).is(':checked');
        toggleYouSaveModeFields(enabled);
        if (!enabled) {
            toggleYouSaveGlobalFields(false);
            $('#ppc_you_save_set_individual, #ppc_you_save_set_global').prop('checked', false);
        } else if ($('#ppc_you_save_set_global').is(':checked')) {
            toggleYouSaveGlobalFields(true);
        }
    });
    $('#ppc_you_save_set_global').on('change', function () {
        const checked = $(this).is(':checked');
        if (checked) {
            $('#ppc_you_save_set_individual').prop('checked', false);
            toggleYouSaveGlobalFields(true);
        } else {
            toggleYouSaveGlobalFields(false);
        }
    });
    $('#ppc_you_save_set_individual').on('change', function () {
        if ($(this).is(':checked')) {
            $('#ppc_you_save_set_global').prop('checked', false);
            toggleYouSaveGlobalFields(false);
        }
    });
    initializeYouSaveState();

    // --- PDF Uploader Section ---
        var $pdfInput = $('#_ppc_attachment_pdf_url');
        $('.ppc-upload-pdf').off('click').on('click', function(e) {
            e.preventDefault();
            var custom_uploader = wp.media({
                title: 'Select PDF',
                library: { type: 'application/pdf' },
                button: { text: 'Use this PDF' },
                multiple: false
            });
            custom_uploader.on('select', function() {
                var attachment = custom_uploader.state().get('selection').first().toJSON();
                $pdfInput.val(attachment.url);
            });
            custom_uploader.open();
        });
    

    // --- Variants Table Settings Section ---
    function toggleVariantsGlobalFields(show) {
        $('.ppc_variants_global_field').closest('tr').toggle(show);
    }
    function toggleVariantsFields() {
        const enabled = $('#ppc_enable_variants_table').is(':checked');
        $('#ppc_variants_set_individual').closest('tr').toggle(enabled);
        $('#ppc_variants_set_global').closest('tr').toggle(enabled);
        if (!enabled) {
            $('#ppc_variants_set_individual').prop('checked', false);
            $('#ppc_variants_set_global').prop('checked', false);
        }
    }
    $('#ppc_variants_set_individual').on('change', function () {
        if ($(this).is(':checked')) {
            $('#ppc_variants_set_global').prop('checked', false);
        }
    });
    $('#ppc_variants_set_global').on('change', function () {
        if ($(this).is(':checked')) {
            $('#ppc_variants_set_individual').prop('checked', false);
        }
    });
    $('#ppc_enable_variants_table').on('change', toggleVariantsFields);
    toggleVariantsFields();
  
});